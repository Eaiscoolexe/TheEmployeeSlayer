# The Doom Bracken 
This mod gives the Bracken sounds from Doom Eternal.

## How to use this mod 
- Use mod manager to install 
or 
- install all dependencies
- move the DoomBracken folder from the CustomSounds folder into yours